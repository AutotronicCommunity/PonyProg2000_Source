//===============================================================
// vstatusp.h - Status Bar class .h file - Windows
//
// Copyright (C) 1995  Bruce E. Wampler
//
// This file is part of the V C++ GUI Framework, and is covered
// under the terms of the GNU Library General Public License,
// Version 2. This library has NO WARRANTY. See the source file
// vapp.cxx for more complete information about license terms.
//===============================================================

#ifndef VSTATUSP_H
#define VSTATUSP_H

#include <v/vcmdpane.h>

#endif
