#ifndef	INCLUDE_STRING_TABLE_H
#define	INCLUDE_STRING_TABLE_H

#define	STR_LANGUAGE_CODE	"Deutsch"

#define	MSG_TRANSLATORCREDITS	"Translator Credits:"			//i wouldn't translate this one!
#define	MSG_TRANSLATORNAME	"Thilo Lauer"

#define	STR_APPNAME_EXT		"Serieller Device-Programmierer - mod by Dietrich Kindermann"
#define	STR_APPDOWNLOAD1	"Laden Sie die aktuelle Version von"
#define	STR_APPDOWNLOAD2	"unter der Adresse:"

#define	STR_NONAME		"Kein Name"

//Button captions
#ifdef	WIN32
#define	STR_BTNOK		" &OK "
#define	STR_BTNCANC		" &Abbruch "
#define	STR_BTNHELP		" &Hilfe "
#define	STR_BTNPROBE	" &Test "
#else
#define STR_BTNOK		"  OK "
#define	STR_BTNCANC		"  Abbruch "
#define	STR_BTNHELP		"  Hilfe "
#define	STR_BTNPROBE	"  Test "
#endif

#define	STR_BTNNOTE		"Bemerkung"
#define	STR_BTNEDIT		"Bearbeiten"


//Dialog messages
#define	STR_MSGVERSION	    "Version"
#define	STR_MSGYES		    "Ja"
#define	STR_MSGNO		    "Nein"
#define	STR_MSGOK		    "Ok"
#define	STR_MSGTEST		    "Test"
#define	STR_MSGFAILED		"Fehler"
#define	STR_ABOUT		    "�ber"
#define	STR_MSGPAGE		    "Seite"
#define	STR_MSGUNKNOWN		"Unbekannt"
#define STR_VGUIABOUT		"Dieses Programm benutzt die V Bibliothek.\nDie V Bibliothek ist von Bruce E.Wampler urheberrechtlich gesch�tzt.\nSie ist zu finden unter\nhttp://www.objectcentral.com"
#define	STR_BUFCHANGED		"Puffer \"%s\" ge�ndert. Speichern vor dem Beenden?"
#define	STR_BUFCHANGED2		"Puffer ge�ndert. Speichern vor dem Beenden?"
#define	STR_NOTHINGSAVE		"Nichts zu speichern"
#define	STR_NOTHINGLOAD		"Nichts zu laden"
#define	STR_NOTHINGPRINT	"Nichts zu drucken"
#define	STR_NOTHINGWRITE	"Nichts zu schreiben"
#define	STR_NOTHINGVERIFY	"Nichts zu vergleichen"
#define	STR_BUSCALIBRA1		"Bus-Timing-Kalibrierung. \nStellen Sie sicher, dass keine Anwendung l�uft, au�er "
#define	STR_BUSCALIBRA2		"\n(CPU und Festplatte sollten im Leerlauf sein)\nDie Kalibrierung kann einige Sekunden dauern.\nWollen Sie die Kalibrierung jetzt starten?"
#define	STR_BUSCALIBRAOK	"Kalibrierung OK"
#define	STR_BUSCALIBRAFAIL	"Kalibrierung fehlgeschlagen"
#define	STR_MSGNEEDCALIB	"Sie m�ssen Kalibrieren im Optionen-Men� ausf�hren\nbevor Sie irgendwelche Lese/Schreib-Vorg�nge starten"
#define	STR_MSGNEEDSETUP	"Sie m�ssen Setup im Optionen-Men� ausf�hren\nbevor Sie irgendwelche Lese/Schreib-Vorg�nge starten"
#define	STR_MSGREADING		"Lesen..."
#define	STR_MSGREADOK		"Lesen erfolgreich\nDevice-Gr��e:"
#define	STR_MSGREADOK2		"Bytes\n'Bank roll-over' Erkennung fehlgeschlagen"
#define	STR_MSGREADOK3		"Bytes\n'Bank roll-over' Kapazit�t:"
#define	STR_ASKWRITE		"Sind Sie sicher, das Device beschreiben zu wollen?\nJeglicher Inhalt geht verloren"
#define	STR_MSGWRITING		"Schreiben..."
#define	STR_MSGVERIFING		"Vergleichen..."
#define	STR_MSGWRITEOK		"Schreiben erfolgreich"
#define	STR_MSGWRITEFAIL	"Schreiben fehlgeschlagen"
#define	STR_MSGERASING		"L�schen..."
#define	STR_MSGERASEOK		"L�schen erfolgreich"
//#define	STR_MSGVERIFING	"Vergleichen..."
#define	STR_MSGVERIFYFAIL1	"Kein vergleichen m�glich, falsches oder fehlendes Device"
#define	STR_MSGVERIFYFAIL2	"Vergleichen fehlgeschlagen"
#define	STR_MSGVERIFYOK		"Vergleichen erfolgreich"
#define	STR_MSGPROGRAMOK	"Programmierung erfolgreich"
#define	STR_MSGPROGRAMFAIL	"Programmierung fehlgeschlagen"
#define	STR_MSGDEVRESET		"Device zur�ckgesetzt"
#define	STR_MSGWRITINGSEC	"Schreibe Security Bits..."
#define	STR_MSGWRITESECFAIL	"Schreiben der Security Bits fehlgeschlagen"
#define	STR_MSGREADINGSEC	"Lese Security Bits..."
#define	STR_MSGREADSECFAIL	"Lesen der Konfigurationsbits fehlgeschlagen"
#define	STR_MSGREADINGFUSE	"Lese Konfigurationsbits..."
#define	STR_MSGREADFUSEFAIL	"Lesen der Konfigurationsbits fehlgeschlagen"
#define	STR_MSGWRITINGFUSE	"Schreibe Konfigurationsbits..."
#define	STR_MSGWRITEFUSEFAIL	"Schreiben der Konfigurationsbits fehlgeschlagen"

#define	STR_BUFEMPTY		"Puffer leer"
#define	STR_OPNOTSUP		"Aktion nicht unterst�tzt"
#define	STR_MSGINSPARAM		"Parameter einf�gen"
#define	STR_MSGBADPARAM		"Falsche Parameter"
#define	STR_MSGACCEPTCMD	"Befehl akzeptiert..."
#define	STR_MSGOPENFILE		"Datei mit Device-Inhalt �ffnen"
#define	STR_MSGFILENOTFOUND	"Datei nicht gefunden"
#define	STR_MSGFILESAVEFAIL	"Datei sichern fehlgeschlagen"
#define	STR_MSGFILESAVEAS	"Datei speichern unter"
#define	STR_MSGFILESAVEPROG	"Speichere Programm (FLASH) Inhalt unter"
#define	STR_MSGFILESAVEDATA	"Speichere Data (EEPROM) Inhalt unter"
#define	STR_MSGCLOSEWINEXIT	"Fenster schlie�en: Wollen sie beenden?"
#define	STR_MSGCLOSEWINSAVE	"Puffer ge�ndert. Speichern vor dem Beenden?"


//Menu entries

//Main Menu
#define	STR_MENUFILE		"&Datei"
#define	STR_MENUEDIT		"&Bearbeiten"
#define	STR_MENUDEVICE		"&Device"
#define	STR_MENUCMD		    "&Befehl"
#define	STR_MENUUTIL		"&Tools"
#define	STR_MENUSETUP		"&Setup"
#define	STR_MENUOPTIONS		"&Optionen"
#define	STR_MENUQMARK		"&?"

//Menu File
#define	STR_NEWWIN		"&Neues Fenster"
#define	STR_OPEN		"&�ffne Device Datei..."
#define	STR_OPENFLASH	"�ffne &Programm (FLASH) Datei..."
#define	STR_OPENDATA	"�ffne &Daten (EEPROM) Datei..."
#define	STR_SAVE		"&Speichere Device Datei"
#define	STR_SAVEAS		"Speichere Device Datei &unter..."
#define	STR_SAVEFLASH	"Speichere Programm (&FLASH) Datei unter..."
#define	STR_SAVEDATA	"Speichere Daten (&EEPROM) Datei unter..."
#define	STR_RELOAD		"&Dateien wiederherstellen"
#define	STR_PRINT		"Drucken..."
#define	STR_CLOSE		"&Schlie�en"
#define	STR_EXIT		"&Beenden"

//Menu Edit
#define	STR_EDITNOTE		"Edit &Note..."
#define	STR_EDITBUFENA		"Edit Bu&ffer eingeschaltet"

//Menu Command
#define	STR_READALL		    "&Lese alles"
#define	STR_READPROG		"Lese Program (FLASH)"
#define	STR_READDATA		"Lese Data (EEPROM)"
#define	STR_READSECBITS		"Lese &Security und Konfigurationsbits"
#define	STR_WRITEALL		"&Schreibe alles"
#define	STR_WRITEPROG		"Schreibe Program (&FLASH)"
#define	STR_WRITEDATA		"Schreibe Data (EEPROM)"
#define	STR_WRITESECBITS	"Schre&ibe Security and Konfigurationsbits"
#define	STR_VERIFYALL		"&Vergleiche alles"
#define	STR_VERIFYPROG		"Vergleiche Program (FLASH)"
#define	STR_VERIFYDATA		"Vergleiche Data (EEPROM)"
#define	STR_VERIFYSECBITS	"Vergleiche Security and Konfigurationsbits"
#define	STR_ERASE		    "&L�schen"
#define	STR_GETINFO		    "&Info holen"
#define	STR_RESET		    "Rese&t"
#define	STR_PROGRAM		    "&Programm"
#define	STR_PROGOPTION		"Programm Optionen..."

//Menu Options
#define	STR_INTERFSETUP		"&Hardware Setup..."
#define	STR_CALIBRATION		"&Kalibrierung"
#define	STR_REMOTEMODE		"&Fernbedienungs-Modus"

//Menu Utility
#define	STR_CLEARBUF	"&L�sche Puffer"
#define	STR_FILLBUF	    "&F�lle Puffer..."
#define	STR_DOUBLEBANK	"&Double Bank"
#define	STR_BYTESWAP	"&Byte Tausch"
#define	STR_DOWNSERNUM	"Setze Serien&nummer"
#define	STR_SERNUMCONF	"Seriennummer konfigurieren..."

//Menu Help
#define	STR_MENUHELP	"&Hilfe"
#define	STR_MENUABOUT	"&�ber"

//Menu Options
#define	STR_MENULOG		"&Log Datei..."


//Tool Bar

//Dialog Messages
#define	STR_MSGDEVTYPE	"Dev.Type"

//Tool tips
#define	STR_TTOPENFILE	"�ffne Device Datei"
#define	STR_TTSAVEFILE	"Speichere Device Datei"
#define	STR_TTPRINT	    "Drucke Puffer"
#define	STR_TTRELOAD	"Dateien wiederherstellen"
#define	STR_TTREADALL	"Lese Device"
#define	STR_TTREADPROG	"Lese Programmspeicher (FLASH)"
#define	STR_TTREADDATA	"Lese Data Speicher (EEPROM)"
#define	STR_TTREADSEC	"Lese Security und Konfigurationsbits"
#define	STR_TTWRITEALL	"Schreibe Device"
#define	STR_TTWRITEPROG	"Schreibe Programmspeicher (FLASH)"
#define	STR_TTWRITEDATA	"Schreibe Datenspeicher (EEPROM)"
#define	STR_TTWRITESEC	"Schreibe Security und Konfigurationsbits"
#define	STR_TTVERIFYPROG "Vergleiche Programmspeicher (FLASH)"
#define	STR_TTVERIFYDATA "Vergleiche Datenspeicher (EEPROM)"
#define	STR_TTVERIFYSEC	"Vergleiche Security und Konfigurationsbits"

#define	STR_TTSELFAMILY	"W�hle Device-Familie"
#define	STR_TTSELTYPE	"W�hle Device-Typ"

#define	STR_TTEDITNOTE	"Bearbeite Device-Beschreibung"


//Error Messages
#define	STR_DEVNOTRESP	"Device antwortet nicht"
#define	STR_DEVBADTYPE	"Falsches Device, bitte den richtigen Typ w�hlen"
#define	STR_DEVUNKNOWN	"Falsches oder fehlendes Device"
#define	STR_DEVLOCKED	"Kein Zugriff, Device defekt oder gesperrt"
#define	STR_OPABORTED	"Abbruch durch Benutzer"
#define	STR_OPENFAILED	"Kommunikationsport nicht verf�gbar"
#define	STR_ACCDENIED	"I/O-Zugriff verweigert. Administrator-Rechte erforderlich"
#define	STR_NOTINST	    "Programmer nicht gefunden"
#define	STR_HWERROR	    "Hardware-Fehler, richtig angeschlossen?"
#define	STR_BUSBUSY	    "Bus-Leitung besetzt oder Hardware-Fehler"
#define	STR_I2CNOACK	"Fehlende Best�tigung vom Device"
#define	STR_I2CNODEV	"Fehlendes Device"
#define	STR_I2CTIMEOUT	"Zeit�berschreitung der Bus-Leitung"
#define	STR_I2CSTOPERR	"I2CBus Stop Fehler (falsches Timing?)"
#define	STR_WRITEERR	"Fehler beim schreiben"
#define STR_BLANKCHECKERR "Fehler beim Leertest"
#define	STR_ERRNO	"unbekannter Fehler"




//----Setup dialog

//Dialog title
#define	STR_DLGIOSETUP		"I/O-Port-Setup"
#define	STR_MSGINTSETUP		"Hardware Setup"

//Dialog messages
#define	STR_LBLCOMLPT		"COM/LPT Hardware"
#define	STR_LBLSERIAL		" Seriell  "
#define	STR_LBLPARALLEL		" Parallel  "
#define	STR_LBLINTERFSEL	" Hardware-Auswahl "
#define	STR_LBLINTERFTYPE	" Hardware-Typ "
#define	STR_LBLCOMSELECT	" COM-Port-Auswahl "
#define	STR_LBLCOM1		" COM1  "
#define	STR_LBLCOM2		" COM2  "
#define	STR_LBLCOM3		" COM3  "
#define	STR_LBLCOM4		" COM4  "
#define	STR_LBLLPTSELECT	" LPT-Port-Auswahl "
#define	STR_LBLLPT1		" LPT1  "
#define	STR_LBLLPT2		" LPT2  "
#define	STR_LBLLPT3		" LPT3  "
#define	STR_LBLLPT4		" LPT4  "
#define	STR_LBLSELPOLARITY	" Polarit�tswahl der Kontroll-Leitungen"
#define	STR_LBLINVRESET		" Invertiere Reset "
#define	STR_LBLINVSCK		" Invertiere SCKL  "
#define	STR_LBLINVDATAIN	" Invertiere D-IN  "
#define	STR_LBLINVDATAOUT	" Invertiere D-OUT "

//Tool tips

#define	STR_TTCOM1		"W�hle Seriellen Port COM1"
#define	STR_TTCOM2		"W�hle Seriellen Port COM2"
#define	STR_TTCOM3		"W�hle Seriellen Port COM3"
#define	STR_TTCOM4		"W�hle Seriellen Port COM4"
#define	STR_TTLPT1		"W�hle Parallelen Port LPT1"
#define	STR_TTLPT2		"W�hle Parallelen Port LPT2"
#define	STR_TTLPT3		"W�hle Parallelen Port LPT3"


//----Fill dialog

//Dialog title
#define	STR_LBLFILLBUF		"F�lle Puffer"

//Dialog messages: NB should be of the same size (number of char)
#define	STR_LBLFROM		" Von   "
#define	STR_LBLTO		" Bis   "
#define	STR_LBLVALUE	" Wert  "



//----Fuse dialog

//Button captions
#ifdef	WIN32
#define	STR_BTNCLRALL		" L�sche alle "
#define	STR_BTNSETALL		" &Setze alle "
#define	STR_BTNWRITE		" Sch&reiben "
#define	STR_BTNREAD		    " &Lesen "
#else
#define	STR_BTNCLRALL		" L�sche alle "
#define	STR_BTNSETALL		" Setze alle "
#define	STR_BTNWRITE		" Schreiben "
#define	STR_BTNREAD		    " Lesen "
#endif

//Dialog title
#define	STR_MSGFUSEDLG		"Security und Konfigurationsbits"

//Dialog messages: NB should be of the same size (number of char)
#define	STR_MSGFIRSTBLK		" Erster zu sperrender Block   "
#define	STR_MSGNUMBLOCK		" Nr. der zu sperrenden Bl�cke "
#define	STR_MSGHIGHENDBLK	" High endurance block         "

//Tool tips
#define	STR_TTCLRALL		"Alle Bits auf '0'"
#define	STR_TTSETALL		"Alle Bits auf '1'"
#define	STR_TTWRITE		    "Schreibe Bits in Device"
#define	STR_TTREAD		    "Lese Bits aus Device"


//----Info dialog

//Button captions
#ifdef	WIN32
#define	STR_BTNCLOSE		" &Schlie�en "
#else
#define	STR_BTNCLOSE		"  Schlie�en "
#endif

//Dialog title
#define	STR_MSGDEVINFO		"Device Information"

//Dialog messages
#define	STR_MSGBANKROLL		"F�higkeit zu Bank roll-over:"
#define	STR_MSGSIZE		    "Gr��e:"
#define	STR_MSGCRC		    "CRC:"
#define	STR_MSGSECBLOCK		"Security Block:"
#define	STR_HIGHENDURAN		"High endurance block:"


//----Char Edit dialog

//Dialog title
#define	STR_MSGEDITBUG		"Editiere Puffer"

//Dialog messages: NB should be of the same size (number of char)
#define	STR_MSGHEX		" Hex     "
#define	STR_MSGDECIMAL	" Dezimal "
#define	STR_MSGCHAR		" Ascii   "

//Tool tips
#define	STR_TTHEX		"Hexadezimal-Wert"
#define	STR_TTDECIMAL	"Dezimal-Wert"
#define	STR_TTCHAR		"ASCII-Wert"


//----Program Option dialog

//Dialog title
#define	STR_MSGPROGOPT		"Programm-Optionen"

//Dialog messages
#define	STR_MSGRELOAD		"Dateien wiederherstellen"
#define	STR_MSGREADPROG		"Lese Programmspeicher (FLASH)"
#define	STR_MSGREADDATA		"Lese Datenspeicher (EEPROM)"
#define	STR_MSGREADSERNUM	"Lese Seriennummer"
#define	STR_MSGBYTESWAP		"Byte-Tausch"
#define	STR_MSGSERNUM		"Setze Seriennummer"
#define	STR_MSGERASE		"L�schen"
#define	STR_MSGWRITEPROG	"Schreibe Programmspeicher (FLASH)"
#define	STR_MSGWRITEDATA	"Schreibe Datenspeicher (EEPROM)"
#define	STR_MSGWRITESEC		"Schreibe Security- und Konfigurationsbits"
#define	STR_MSGVERIFYSEC	"Vergleiche Security- und Konfigurationsbits"



//----Serial Number dialog

//Dialog title
#define	STR_MSGSERNUMCFG	"Seriennummer-Konfiguration"

//Dialog messages: NB should be of the same size (number of char)
#define	STR_MSGADDRESS		" Addresse "
#define	STR_MSGSIZE2		" Gr��e    "
#define	STR_MSGVALUE		" Wert     "
#define	STR_MSGFORMAT		" Format   "

//next 2 probably can't be translated
#define	STR_MSGLITTLEEND	"Little endian"
#define	STR_MSGBIGENDIAN	"Big endian"

#define	STR_MSGOFFSET		"Datenspeicher-Offset"

//Tool tips

#define	STR_TTSNMEMADDR		"Speicher-Addressen"
#define	STR_TTSNSIZE		"Gr��e in Bytes"
#define STR_TTSNVALUE		"N�chster benutzter Wert"
#define	STR_TTSNOFFSET		"Verwenden Sie die Addresse relativ zum Datenspeicher anstelle des Programmspeichers"
#define	STR_TTLITTLEEND		"H�herwertiges Byte an hohe Adresse"
#define	STR_TTBIGENDIAN		"H�herwertiges Byte an niedrige Adresse"


//----Retry dialog

//Button captions
#ifdef	WIN32
#define	STR_BTNABORT	" &Abbruch "
#define	STR_BTNRETRY	" &Wiederholen "
#define	STR_BTNIGNORE	" &Ignorieren "
#else
#define	STR_BTNABORT	" Abbruch "
#define	STR_BTNRETRY	" Wiederholen "
#define	STR_BTNIGNORE	" Ignorieren "
#endif

//Dialog title
#define	STR_MSGALERT	"Alarm"


//----Notes dialog

//Dialog title
#define	STR_MSGDEVNOTE	"Editiere Device-Beschreibung"


//----Progress dialog

//Dialog title
#define	STR_MSGSTATUS	"Status"


//Script
#define	STR_MENUSCRIPT	"Scri&pt"
#define	STR_EDITSCR		"&Editieren..."
#define	STR_LOADSCR		"&Laden und Ausf�hren..."
#define	STR_AUTOLOADSCR	"A&utomatisch ausf�hren"
#define	STR_RUNSCR		"&Ausf�hren"

#define STR_MSGSCRIPTERROR	     "Script-Fehler in Zeile "
#define	STR_MSGSCRIPTBADCOMMAND  "Falsches Kommando"
#define	STR_MSGSCRIPTBADARGUMENT "Falsches Argument"
#define	STR_MSGSCRIPTARGMISSING	 "Fehlendes Argument"
#define	STR_MSGDEFAULTPAUSE	     "Wollen Sie weiterarbeiten?"
#define	STR_MSGOPENSCRIPT	     "Script-Datei �ffnen"
#define	STR_SCRIPTERROR		     "Script-Fehler"

#define	STR_MSGOPENPROGFILE	"�ffne Programmspeicher-Datei (FLASH)"
#define	STR_MSGOPENDATAFILE	"�ffne Datenspeicher-Datei (EEPROM)"

#define	STR_MSGINSNEWVAL	"Geben Sie den neuen Wert ein"
#define	STR_MSGENTERTEXT	"Geben Sie den neuen Text ein"

#define	STR_LBLNOSOUND		"Sound deaktivieren"


//---- Oscillator Calibration Byte
#define	STR_MSGOSCCALIBCFG	"Kalibrierungsbyte f�r Oszillator"

#define	STR_READOSCCALIB	"Lese Kalibrierungsbyte f�r Oszillator"
#define	STR_OSCCALIBOPTION	"Optionen f�r Oszillator-Kalibrierung..."
#define	STR_MSGREADCALIBOK	"Lesen des Kalibrierungsbytes f�r Oszillator erfolgreich"

#define	STR_MSGCHIPID	" Chip-Kennung"
#define STR_MSGNOTE		" Bemerkung"
#define	STR_MSGEEPSIZE	"EEPROM-Gr��e"
#define	STR_MSGFLASHSIZE	"FLASH-Gr��e"

#define	STR_MSGSNAUTOINC	"Autoinkrementalmodus"
#define	STR_TTSNAUTOINC		"Erh�he die Seriennummer nach jeder 'Setze Seriennummer'-Operation"
#define STR_MSGBANKROLLOVER "EEPROM Bank Roll-over-Test erfordert Schreibzugriff. Zugriff durchf�hren?"
#define STR_BUFCHANGED3     "Buffer wurde modifiziert. Vor dem Lesen sichern?"


#define STR_TTOPENPROG	"Programmdatei �ffnen (FLASH)"
#define STR_TTOPENDATA	"Datendatei �ffnen (EEPROM)"
#define STR_TTSAVEPROG	"Programmdatei speichern (FLASH)"
#define STR_TTSAVEDATA	"Datendatei speichern (EEPROM)"
#define STR_TTNEWWIN	"Neues Fenster"
#define STR_TTPROGRAM	"Programmierung starten"
#define STR_TTSCRIPT	"Script ausf�hren"
#define STR_TTSETUP		"Setup-Dialog �ffnen"
#define STR_TTERASE		"Komplettes Device mit FF l�schen"

#define STR_SECBITS		"Sicherheit- und Konfigurations&bits..."
#define STR_TTSECBITS	"Sicherheit- und Konfigurationsbits"

//These strings are added to the 'Configuration and security bits' dialog to explain
// that checked items (bits selected with a 'X') means to program the bit
#define STR_LBLFUSEDLGHLP	"Bitte mit Datenblatt vergleichen"
#define	STR_FUSEDLGNOTESET	"markierte K�stchen bedeuten Programmiert"
#define	STR_FUSEDLGNOTECLR	"leere K�stchen bedeuten Unprogrammiert"

#endif

